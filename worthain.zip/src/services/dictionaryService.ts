import { GoogleGenAI, Type } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || '' });

export interface WordDetails {
  term: string;
  translation: string;
  meaning: string;
  level: 'A1' | 'A2' | 'B1' | 'B2' | 'C1' | 'C2';
  grammar: {
    genus?: 'maskulin' | 'feminin' | 'neutrum';
    type?: string; // Nomen, Verb, Adjektiv
    plural?: string;
  };
  examples: { de: string; en: string }[];
  frequency: number; // 1-5
  frequencyContext?: string; // e.g., "Gehört zu den häufigsten 3.000 Wörtern."
  relatedWords: { term: string; translation: string }[];
  similarWords: string[];
  wordFamily: { term: string; translation: string }[];
}

export async function fetchWordDetails(word: string): Promise<WordDetails> {
  if (!process.env.GEMINI_API_KEY) {
    throw new Error('GEMINI_API_KEY is missing');
  }

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: `Find detailed vocabulary information for the German word: "${word}". Provide English translations and context.`,
    config: {
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          term: { type: Type.STRING },
          translation: { type: Type.STRING },
          meaning: { type: Type.STRING },
          level: { type: Type.STRING, enum: ["A1", "A2", "B1", "B2", "C1", "C2"] },
          grammar: {
            type: Type.OBJECT,
            properties: {
              genus: { type: Type.STRING, enum: ["maskulin", "feminin", "neutrum"] },
              type: { type: Type.STRING },
              plural: { type: Type.STRING }
            }
          },
          examples: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                de: { type: Type.STRING },
                en: { type: Type.STRING }
              },
              required: ["de", "en"]
            }
          },
          frequency: { type: Type.NUMBER },
          frequencyContext: { type: Type.STRING },
          relatedWords: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                term: { type: Type.STRING },
                translation: { type: Type.STRING }
              }
            }
          },
          similarWords: {
            type: Type.ARRAY,
            items: { type: Type.STRING }
          },
          wordFamily: {
            type: Type.ARRAY,
            items: {
              type: Type.OBJECT,
              properties: {
                term: { type: Type.STRING },
                translation: { type: Type.STRING }
              }
            }
          }
        },
        required: ["term", "translation", "meaning", "level", "grammar", "examples", "frequency"]
      }
    }
  });

  try {
    return JSON.parse(response.text);
  } catch (e) {
    console.error("Failed to parse AI response", response.text);
    throw new Error("Invalid dictionary data received");
  }
}
