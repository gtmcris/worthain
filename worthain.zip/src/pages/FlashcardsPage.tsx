import React, { useState, useEffect } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { collection, query, where, getDocs, doc, updateDoc, increment, serverTimestamp, addDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Vocabulary } from '../types';
import { Button, Card } from '../components/UI';
import { X, Check, Volume2, RotateCcw, ChevronLeft, Settings } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';
import { useNavigate } from 'react-router-dom';

export function FlashcardsPage() {
  const { user } = useAuth();
  const navigate = useNavigate();
  const [cards, setCards] = useState<Vocabulary[]>([]);
  const [currentIndex, setCurrentIndex] = useState(0);
  const [isFlipped, setIsFlipped] = useState(false);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (user) fetchCards();
  }, [user]);

  const fetchCards = async () => {
    if (!user) return;
    const q = query(
      collection(db, 'vocabularies'), 
      where('userId', '==', user.uid),
      where('status', 'in', ['learning', 'favorite'])
    );
    const querySnapshot = await getDocs(q);
    const words = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() } as Vocabulary));
    // Shuffle cards
    setCards(words.sort(() => Math.random() - 0.5).slice(0, 20));
    setLoading(false);
  };

  const handleResult = async (result: 'easy' | 'good' | 'hard' | 'again') => {
    if (!user || !cards[currentIndex]) return;
    
    const vocabId = cards[currentIndex].id!;
    const masteryDelta = result === 'easy' ? 10 : result === 'good' ? 5 : result === 'hard' ? -2 : -5;
    
    // Update vocabulary mastery
    await updateDoc(doc(db, 'vocabularies', vocabId), {
      mastery: increment(masteryDelta),
      updatedAt: serverTimestamp()
    });

    // Log practice
    await addDoc(collection(db, 'practice_logs'), {
      userId: user.uid,
      vocabId,
      result,
      timestamp: serverTimestamp()
    });

    nextCard();
  };

  const nextCard = () => {
    setIsFlipped(false);
    if (currentIndex < cards.length - 1) {
      setCurrentIndex(currentIndex + 1);
    } else {
      // Session finished
      navigate('/stats');
    }
  };

  if (loading) return null;
  if (cards.length === 0) return (
    <div className="min-h-screen flex flex-col items-center justify-center p-8 text-center space-y-6">
       <Card className="p-12 space-y-6">
          <BookSize className="w-20 h-20 text-slate-200 mx-auto" />
          <h2 className="text-xl font-bold text-slate-800">Keine Karten zum Üben</h2>
          <p className="text-slate-400">Speichere zuerst ein paar Vokabeln, um mit dem Training zu beginnen.</p>
          <Button onClick={() => navigate('/search')}>Vokabeln finden</Button>
       </Card>
    </div>
  );

  const currentWord = cards[currentIndex];

  return (
    <div className="min-h-screen bg-brand-bg pb-40">
      <header className="px-6 pt-16 flex items-center justify-between">
        <button onClick={() => navigate(-1)} className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center text-slate-400">
          <ChevronLeft size={24} />
        </button>
        <div className="text-center">
           <p className="text-[10px] font-black text-slate-300 uppercase tracking-ultra">Training Session</p>
           <p className="text-sm font-black text-slate-900">{currentIndex + 1} / {cards.length}</p>
        </div>
        <div className="w-12 h-12" />
      </header>

      <main className="px-8 mt-12 flex flex-col items-center">
        <div className="w-full max-w-sm perspective-1000 aspect-[4/5] relative">
          <AnimatePresence mode="wait">
            <motion.div
              key={currentIndex}
              initial={{ x: 300, opacity: 0, rotate: 10 }}
              animate={{ x: 0, opacity: 1, rotate: 0 }}
              exit={{ x: -300, opacity: 0, rotate: -10 }}
              className="w-full h-full relative cursor-pointer"
              onClick={() => setIsFlipped(!isFlipped)}
            >
              <motion.div 
                className="w-full h-full relative preserve-3d"
                animate={{ rotateY: isFlipped ? 180 : 0 }}
                transition={{ type: 'spring', stiffness: 200, damping: 20 }}
                style={{ transformStyle: 'preserve-3d' }}
              >
                {/* Front */}
                <Card className="absolute inset-0 backface-hidden flex flex-col items-center justify-center text-center p-10 border-none shadow-2xl shadow-indigo-100">
                  <div className="bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-ultra mb-8">
                     German Word
                  </div>
                  <h2 className="text-5xl font-black text-slate-900 tracking-tight leading-tight mb-4">{currentWord.term}</h2>
                  <p className="text-slate-400 font-medium tracking-wide italic">/{currentWord.grammar.type}/</p>
                  
                  <div className="absolute bottom-10 animate-bounce">
                     <p className="text-[10px] font-black text-slate-300 uppercase tracking-ultra">Tap to flip</p>
                  </div>
                </Card>

                {/* Back */}
                <Card 
                  className="absolute inset-0 backface-hidden flex flex-col items-center justify-center text-center p-10 border-none bg-indigo-600 text-white shadow-2xl shadow-indigo-200"
                  style={{ transform: 'rotateY(180deg)' }}
                >
                  <p className="text-[10px] font-black text-indigo-200 uppercase tracking-ultra mb-8">Translation</p>
                  <h2 className="text-4xl font-black tracking-tight leading-tight mb-6">{currentWord.translation}</h2>
                  <p className="text-indigo-100 text-sm font-medium opacity-80 leading-relaxed max-w-[200px] italic">"{currentWord.exampleSentences[0].de}"</p>
                </Card>
              </motion.div>
            </motion.div>
          </AnimatePresence>
        </div>

        <div className="mt-16 w-full max-w-sm flex gap-4">
          <Button variant="outline" className="flex-1 py-5 border-slate-200 text-slate-400" onClick={(e) => { e.stopPropagation(); handleResult('again'); }}>
             Again
          </Button>
          <Button className="flex-1 py-5 shadow-xl shadow-emerald-100 bg-emerald-500 hover:bg-emerald-600 border-none" onClick={(e) => { e.stopPropagation(); handleResult('easy'); }}>
             Mastered
          </Button>
        </div>
      </main>
    </div>
  );
}

function BookSize({ className }: { className?: string }) {
  return (
    <svg className={className} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
      <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
      <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2z" />
    </svg>
  );
}
