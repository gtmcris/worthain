import React, { useState } from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Card } from '../components/UI';
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LineChart, Line } from 'recharts';
import { ChevronDown } from 'lucide-react';
import { cn } from '../lib/utils';

export function StatsPage() {
  const { profile } = useAuth();
  const [timeRange, setTimeRange] = useState('Letzte 7 Tage');

  const levelData = [
    { label: 'A1', val: 23 },
    { label: 'A2', val: 68 },
    { label: 'B1', val: 112 },
    { label: 'B2', val: 76 },
    { label: 'C1', val: 24 },
    { label: 'C2', val: 9 }
  ];

  const progressData = [
    { date: '13. Mai', words: 120 },
    { date: '14. Mai', words: 145 },
    { date: '15. Mai', words: 180 },
    { date: '16. Mai', words: 165 },
    { date: '17. Mai', words: 210 },
    { date: '18. Mai', words: 250 },
    { date: '19. Mai', words: 280 },
    { date: '20. Mai', words: 312 },
  ];

  return (
    <div className="min-h-screen bg-[#F8F9FE] pb-32">
       <header className="px-6 pt-12 flex justify-between items-end">
          <h1 className="text-2xl font-bold text-slate-900">Statistiken</h1>
          <button className="flex items-center gap-1 text-slate-400 text-sm font-medium border border-slate-100 rounded-lg px-2 py-1 bg-white">
            {timeRange} <ChevronDown size={16} />
          </button>
       </header>

       <main className="px-6 mt-8 space-y-8">
          <div className="grid grid-cols-3 gap-4">
             <Card className="p-4 bg-white/50 border-none flex flex-col items-center justify-center">
                <span className="text-xs font-medium text-slate-300 uppercase tracking-widest">Gelernt</span>
                <span className="text-xl font-bold text-slate-800">32</span>
             </Card>
             <Card className="p-4 bg-white/50 border-none flex flex-col items-center justify-center">
                <span className="text-xs font-medium text-slate-300 uppercase tracking-widest">Wiederholt</span>
                <span className="text-xl font-bold text-slate-800">98</span>
             </Card>
             <Card className="p-4 bg-white/50 border-none flex flex-col items-center justify-center">
                <span className="text-xs font-medium text-slate-300 uppercase tracking-widest">Richtig</span>
                <span className="text-xl font-bold text-emerald-500">86%</span>
             </Card>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-widest pl-2">Worthäufigkeit</h3>
            <p className="text-xs text-slate-400 pl-2">Basierend auf deinen Vokabeln</p>
            <Card className="p-6">
               <div className="h-48 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={levelData}>
                      <XAxis 
                        dataKey="label" 
                        axisLine={false} 
                        tickLine={false} 
                        tick={{ fill: '#cbd5e1', fontSize: 10, fontWeight: 700 }}
                      />
                      <Tooltip 
                        cursor={{ fill: '#f8fafc' }}
                        contentStyle={{ borderRadius: '1rem', border: 'none', boxShadow: '0 4px 6px -1px rgb(0 0 0 / 0.1)' }}
                      />
                      <Bar 
                        dataKey="val" 
                        fill="#6366f1" 
                        radius={[6, 6, 0, 0]}
                        barSize={32}
                      />
                    </BarChart>
                  </ResponsiveContainer>
               </div>
            </Card>
          </div>

          <div className="space-y-4">
            <h3 className="text-sm font-bold text-slate-900 uppercase tracking-widest pl-2">Fortschritt</h3>
            <Card className="p-6 overflow-hidden">
               <div className="h-48 w-full -ml-4 -mb-4">
                  <ResponsiveContainer width="110%" height="110%">
                    <LineChart data={progressData}>
                      <XAxis 
                        dataKey="date" 
                        hide
                      />
                      <Tooltip />
                      <Line 
                        type="monotone" 
                        dataKey="words" 
                        stroke="#6366f1" 
                        strokeWidth={3} 
                        dot={{ r: 4, fill: '#6366f1', strokeWidth: 2, stroke: '#fff' }}
                        activeDot={{ r: 6, strokeWidth: 0 }}
                      />
                    </LineChart>
                  </ResponsiveContainer>
               </div>
               <div className="flex justify-between mt-4 px-2">
                 <div className="space-y-0.5">
                    <p className="text-[10px] text-slate-300 font-bold uppercase tracking-widest">Wörter</p>
                    <p className="text-lg font-bold text-slate-800">400</p>
                 </div>
                 <div className="space-y-0.5 text-right">
                    <p className="text-[10px] text-slate-300 font-bold uppercase tracking-widest">Datum</p>
                    <p className="text-sm font-bold text-slate-800">22. Mai</p>
                 </div>
               </div>
            </Card>
          </div>
       </main>
    </div>
  );
}
