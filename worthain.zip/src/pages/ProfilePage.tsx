import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Card, Button } from '../components/UI';
import { ChevronRight, Settings, Smartphone, HelpCircle, LogOut, Book, GraduationCap, Star, FileText } from 'lucide-react';
import { motion } from 'motion/react';

export function ProfilePage() {
  const { profile, logout } = useAuth();

  const menuItems = [
    { label: 'Mein Vokabular', sub: '312 Wörter', icon: Book, color: 'text-indigo-600', bg: 'bg-indigo-50' },
    { label: 'Zu lernende Wörter', sub: '48 Wörter', icon: GraduationCap, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Favoriten', sub: '12 Wörter', icon: Star, color: 'text-amber-500', bg: 'bg-amber-50' },
    { label: 'Notizen', sub: '14 Notizen', icon: FileText, color: 'text-emerald-500', bg: 'bg-emerald-50' },
  ];

  return (
    <div className="min-h-screen bg-[#F8F9FE] pb-32">
       <header className="px-6 pt-16 pb-8 bg-indigo-600/5 rounded-b-[3rem]">
          <div className="flex flex-col items-center">
             <div className="relative">
                <div className="w-24 h-24 rounded-full border-4 border-white shadow-xl overflow-hidden bg-white">
                   <img 
                    src={profile?.photoURL || "https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&q=80&w=200"} 
                    alt="Profile" 
                    className="w-full h-full object-cover"
                    referrerPolicy="no-referrer"
                   />
                </div>
                <div className="absolute -bottom-1 -right-1 bg-white p-1.5 rounded-full shadow-lg">
                   <div className="w-3 h-3 bg-emerald-500 rounded-full" />
                </div>
             </div>
             <h2 className="mt-4 text-xl font-bold text-slate-900">{profile?.displayName}</h2>
             <p className="text-slate-400 text-sm">{profile?.email}</p>
             <div className="mt-4 bg-indigo-100 text-indigo-600 px-4 py-1 rounded-full text-xs font-bold uppercase tracking-widest flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-indigo-600 rounded-full animate-pulse" />
                Premium
             </div>
          </div>
       </header>

       <main className="px-6 mt-8 space-y-6">
          <Card className="p-2 space-y-1">
            {menuItems.map((item, i) => (
              <button 
                key={item.label} 
                className={cn(
                  "w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors rounded-2xl",
                  i < menuItems.length - 1 && "border-b border-slate-50"
                )}
              >
                <div className="flex items-center gap-4">
                  <div className={cn("w-10 h-10 rounded-xl flex items-center justify-center", item.bg, item.color)}>
                    <item.icon size={20} />
                  </div>
                  <div className="text-left">
                    <p className="text-sm font-bold text-slate-800">{item.label}</p>
                    <p className="text-[10px] text-slate-400 uppercase font-medium tracking-tight">{item.sub}</p>
                  </div>
                </div>
                <ChevronRight size={18} className="text-slate-200" />
              </button>
            ))}
          </Card>

          <Card className="p-2 space-y-1">
             {[
               { label: 'Einstellungen', icon: Settings, color: 'text-slate-400' },
               { label: 'Geräte & Synchronisation', icon: Smartphone, color: 'text-slate-400', trail: 'Letzte Synchro: Heute, 09:41' },
               { label: 'Hilfe & Support', icon: HelpCircle, color: 'text-slate-400' },
             ].map((item, i) => (
               <button 
                key={item.label} 
                className={cn(
                  "w-full flex items-center justify-between p-4 hover:bg-slate-50 transition-colors rounded-2xl",
                  i < 2 && "border-b border-slate-50"
                )}
              >
                <div className="flex items-center gap-4">
                   <item.icon size={20} className={item.color} />
                   <div className="text-left">
                      <p className="text-sm font-bold text-slate-800">{item.label}</p>
                      {item.trail && <p className="text-[10px] text-slate-400">{item.trail}</p>}
                   </div>
                </div>
                <ChevronRight size={18} className="text-slate-200" />
              </button>
             ))}
          </Card>

          <Button variant="outline" className="w-full text-rose-500 border-rose-100 hover:bg-rose-50 border-none justify-start px-8" onClick={logout}>
            <LogOut size={20} />
            Abmelden
          </Button>
       </main>
    </div>
  );
}

import { cn } from '../lib/utils';
