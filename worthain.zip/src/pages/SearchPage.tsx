import React, { useState, useEffect } from 'react';
import { Card, Input, Button } from '../components/UI';
import { Search, Filter, Star, ChevronRight, Loader2, Sparkles } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { fetchWordDetails, WordDetails } from '../services/dictionaryService';
import { collection, query, where, getDocs, addDoc, serverTimestamp } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { useAuth } from '../contexts/AuthContext';
import { Link, useNavigate } from 'react-router-dom';

export function SearchPage() {
  const [searchTerm, setSearchTerm] = useState('');
  const [loading, setLoading] = useState(false);
  const [savedWords, setSavedWords] = useState<any[]>([]);
  const { user } = useAuth();
  const navigate = useNavigate();

  useEffect(() => {
    if (user) {
      fetchSavedWords();
    }
  }, [user]);

  const fetchSavedWords = async () => {
    if (!user) return;
    const q = query(collection(db, 'vocabularies'), where('userId', '==', user.uid));
    const querySnapshot = await getDocs(q);
    const words = querySnapshot.docs.map(doc => ({ id: doc.id, ...doc.data() }));
    setSavedWords(words);
  };

  const handleSearch = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    if (!searchTerm.trim()) return;

    setLoading(true);
    try {
      const details = await fetchWordDetails(searchTerm);
      // For now, let's just navigate to a "preview" or "add" view
      // But the reference image shows a list of results too
      // Let's store the search result and show a card
      setSearchResult(details);
    } catch (error) {
      console.error(error);
    } finally {
      setLoading(false);
    }
  };

  const [searchResult, setSearchResult] = useState<WordDetails | null>(null);

  const saveWord = async () => {
    if (!user || !searchResult) return;
    try {
      await addDoc(collection(db, 'vocabularies'), {
        ...searchResult,
        userId: user.uid,
        status: 'learning',
        mastery: 0,
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp()
      });
      setSearchResult(null);
      setSearchTerm('');
      fetchSavedWords();
    } catch (error) {
      console.error(error);
    }
  };

  return (
    <div className="min-h-screen bg-brand-bg pb-40">
      <header className="px-6 pt-16 space-y-8">
        <div className="flex items-center gap-2 mb-2 pl-2">
           <div className="w-1.5 h-6 bg-indigo-600 rounded-full" />
           <p className="text-xs font-black text-slate-300 uppercase tracking-ultra">Wort Finder</p>
        </div>

        <form onSubmit={handleSearch} className="relative">
          <Input 
            placeholder="Search German or English word..." 
            className="pl-14 h-14 shadow-lg shadow-indigo-100/20 bg-white"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
          <Search size={22} className="absolute left-6 top-1/2 -translate-y-1/2 text-slate-300 transition-colors group-focus-within:text-indigo-600" />
          <button type="button" className="absolute right-6 top-1/2 -translate-y-1/2 text-slate-300 hover:text-indigo-600 transition-colors">
            <Filter size={20} />
          </button>
        </form>

        <div className="flex gap-4 overflow-x-auto no-scrollbar py-2">
          {['Alle', 'Zu lernen', 'Gelernt', 'Favoriten'].map((tab, i) => (
            <button 
              key={tab} 
              className={cn(
                "whitespace-nowrap px-6 py-2 text-[10px] font-black uppercase tracking-ultra rounded-full transition-all",
                i === 0 
                  ? "text-indigo-600 bg-white shadow-sm border border-indigo-50" 
                  : "text-slate-400 hover:text-slate-600"
              )}
            >
              {tab}
            </button>
          ))}
        </div>
      </header>

      <main className="px-6 mt-8 space-y-6">
        {loading && (
          <div className="flex flex-col items-center justify-center py-20 text-indigo-600 space-y-6">
             <div className="relative w-16 h-16">
                <Loader2 className="animate-spin absolute inset-0" size={64} strokeWidth={1} />
                <Sparkles className="absolute inset-0 m-auto text-indigo-300 animate-pulse" size={24} />
             </div>
             <p className="text-xs font-black text-slate-300 uppercase tracking-ultra">KI Profiling läuft...</p>
          </div>
        )}

        {searchResult && !loading && (
          <motion.div initial={{ opacity: 0, scale: 0.95 }} animate={{ opacity: 1, scale: 1 }}>
            <Card className="border-none shadow-xl shadow-indigo-100/30 overflow-hidden group">
              <div className="flex justify-between items-start mb-6">
                <div>
                   <h3 className="text-3xl font-black text-slate-900 tracking-tight">{searchResult.term}</h3>
                   <p className="text-xs font-bold text-slate-400 uppercase tracking-wider mt-1">{searchResult.grammar.type}, {searchResult.grammar.genus}</p>
                </div>
                <div className="bg-indigo-50 text-indigo-600 px-3 py-1 rounded-xl text-xs font-black tracking-ultra">
                  {searchResult.level}
                </div>
              </div>
              
              <div className="h-[1px] w-full bg-slate-50 mb-6" />

              <div className="space-y-2">
                 <p className="text-xl font-bold text-indigo-600">{searchResult.translation}</p>
                 <p className="text-sm text-slate-500 font-medium leading-relaxed">{searchResult.meaning}</p>
              </div>

              <div className="mt-8 flex gap-4">
                <Button onClick={saveWord} className="flex-1">
                   Save to Vault
                </Button>
                <Button variant="secondary" onClick={() => setSearchResult(null)} className="w-14 h-14 p-0">
                   <ChevronRight className="rotate-180" />
                </Button>
              </div>
            </Card>
          </motion.div>
        )}

        <div className="flex justify-between items-center px-1">
          <h2 className="text-sm font-bold text-slate-900 uppercase tracking-wider">
            Alle Vokabeln <span className="text-slate-300 font-normal ml-1">({savedWords.length})</span>
          </h2>
        </div>

        <div className="space-y-3">
          {savedWords.map((word) => (
            <Link key={word.id} to={`/word/${word.id}`}>
              <Card hoverable className="py-4 px-6 flex items-center justify-between group mb-3">
                <div className="space-y-0.5">
                   <div className="flex items-center gap-2">
                     <h4 className="font-bold text-slate-800">{word.term}</h4>
                     {word.status === 'favorite' && <Star size={14} className="fill-amber-400 text-amber-400" />}
                   </div>
                   <p className="text-sm text-slate-500">{word.translation}</p>
                </div>
                <div className="text-right space-y-1">
                   <span className="text-[10px] uppercase font-bold text-slate-300 block">Niveau {word.level}</span>
                   <ChevronRight size={16} className="text-slate-200 group-hover:text-indigo-600 transition-colors ml-auto" />
                </div>
              </Card>
            </Link>
          ))}
          
          {savedWords.length === 0 && !loading && !searchResult && (
            <div className="text-center py-20 px-8">
               <div className="w-16 h-16 bg-slate-50 text-slate-200 rounded-full flex items-center justify-center mx-auto mb-4">
                  <Search size={32} />
               </div>
               <p className="text-slate-400 text-sm">Noch keine Vokabeln gespeichert. Suche oben nach einem Wort!</p>
            </div>
          )}
        </div>
      </main>
    </div>
  );
}

import { cn } from '../lib/utils';
