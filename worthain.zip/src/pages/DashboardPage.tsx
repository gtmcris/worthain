import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Card, Button } from '../components/UI';
import { Book, GraduationCap, Flame, TrendingUp, ChevronRight, PlusCircle, LayoutGrid, Search } from 'lucide-react';
import { motion } from 'motion/react';
import { Link } from 'react-router-dom';

export function DashboardPage() {
  const { profile } = useAuth();

  const stats = [
    { label: 'Vokabeln', value: profile?.stats?.totalWords || 0, sub: 'Gespeichert', icon: Book, color: 'text-indigo-600', bg: 'bg-indigo-50' },
    { label: 'Zu lernen', value: 48, sub: 'Wörter', icon: GraduationCap, color: 'text-purple-600', bg: 'bg-purple-50' },
    { label: 'Serien', value: profile?.stats?.streak || 0, sub: 'Tage', icon: Flame, color: 'text-orange-500', bg: 'bg-orange-50' },
    { label: 'Richtige Antworten', value: '86%', sub: 'Letzte 7 Tage', icon: TrendingUp, color: 'text-emerald-600', bg: 'bg-emerald-50' },
  ];

  return (
    <div className="min-h-screen bg-brand-bg pb-40">
      <header className="px-8 pt-16 pb-10">
        <div className="flex items-center gap-2 mb-2">
           <div className="w-1.5 h-6 bg-indigo-600 rounded-full" />
           <p className="text-xs font-black text-slate-300 uppercase tracking-ultra">Herzlich Willkommen</p>
        </div>
        <h1 className="text-4xl font-extrabold text-slate-900 tracking-tight leading-none">Hallo, {profile?.displayName?.split(' ')[0]}!</h1>
        <p className="text-slate-400 text-sm mt-3 font-medium">Bereit für deine tägliche Dosis Wissen?</p>
      </header>

      <main className="px-6 space-y-10">
        {/* Daily Goal Card */}
        <Card className="flex items-center justify-between py-8 px-10 relative overflow-hidden group">
          <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-50 rounded-full -mr-16 -mt-16 transition-transform group-hover:scale-110 duration-500" />
          
          <div className="space-y-4 relative z-10">
            <div>
               <p className="text-[10px] font-black text-slate-300 uppercase tracking-ultra mb-1">Heutiges Ziel</p>
               <div className="flex items-baseline gap-1">
                 <span className="text-4xl font-black text-indigo-600">12</span>
                 <span className="text-xl font-bold text-slate-300">/ 20</span>
               </div>
            </div>
            <div className="w-40 h-3 bg-slate-100 rounded-full overflow-hidden">
               <motion.div 
                 initial={{ width: 0 }}
                 animate={{ width: '60%' }}
                 className="h-full bg-indigo-600 rounded-full" 
               />
            </div>
          </div>
          <div className="w-16 h-16 flex items-center justify-center bg-white text-indigo-600 rounded-3xl shadow-xl shadow-indigo-100/50 border border-indigo-50 relative z-10">
             <GraduationCap size={32} />
          </div>
        </Card>

        {/* Stats Grid */}
        <div className="grid grid-cols-2 gap-6">
          {stats.map((stat, i) => (
            <Card key={stat.label} className="p-6 space-y-4 border-none shadow-indigo-100/20">
              <div className={cn("w-12 h-12 rounded-2xl flex items-center justify-center shadow-inner", stat.bg, stat.color)}>
                <stat.icon size={22} />
              </div>
              <div className="space-y-0.5">
                 <p className="text-3xl font-black text-slate-900 tracking-tight">{stat.value}</p>
                 <p className="text-[10px] font-black text-slate-400 uppercase tracking-ultra">{stat.label}</p>
              </div>
            </Card>
          ))}
        </div>

        {/* Action List */}
        <div className="space-y-6">
          <div className="flex justify-between items-center px-2">
            <h2 className="text-xs font-black text-slate-300 uppercase tracking-ultra">Fokus-Bereiche</h2>
          </div>
          
          <div className="space-y-4">
            {[
              { label: 'Finder', sub: 'Neue Wörter entdecken', icon: Search, to: '/search', color: 'bg-indigo-600' },
              { label: 'Karten', sub: 'Wissen festigen', icon: LayoutGrid, to: '/practice', color: 'bg-slate-800' },
              { label: 'Fortschritt', sub: 'Daten analysieren', icon: TrendingUp, to: '/stats', color: 'bg-emerald-500' },
            ].map((item) => (
              <Link key={item.label} to={item.to}>
                <Card className="flex items-center justify-between py-5 px-6 mb-4 hover:border-indigo-100 group" hoverable>
                  <div className="flex items-center gap-5">
                    <div className={cn("w-12 h-12 text-white flex items-center justify-center rounded-2xl shadow-lg shadow-indigo-100", item.color)}>
                      <item.icon size={24} />
                    </div>
                    <div>
                      <p className="text-base font-bold text-slate-800">{item.label}</p>
                      <p className="text-xs text-slate-400 font-medium">{item.sub}</p>
                    </div>
                  </div>
                  <div className="w-8 h-8 rounded-full bg-slate-50 flex items-center justify-center text-slate-300 group-hover:bg-indigo-50 group-hover:text-indigo-600 transition-all">
                    <ChevronRight size={18} />
                  </div>
                </Card>
              </Link>
            ))}
          </div>
        </div>
      </main>
    </div>
  );
}

// Helper for cn in this file if needed since I'm export it from utils
import { cn } from '../lib/utils';
