import React from 'react';
import { useAuth } from '../contexts/AuthContext';
import { Button } from '../components/UI';
import { Languages } from 'lucide-react';
import { motion } from 'motion/react';

export function WelcomePage() {
  const { signIn } = useAuth();

  return (
    <div className="min-h-screen bg-brand-bg flex flex-col items-center justify-between px-8 py-16 overflow-hidden">
      <div className="flex-1 flex flex-col items-center justify-center text-center space-y-10">
        <motion.div 
          initial={{ scale: 0, rotate: -20 }}
          animate={{ scale: 1, rotate: 0 }}
          className="w-28 h-28 bg-indigo-600 rounded-[2.5rem] flex items-center justify-center text-white shadow-2xl shadow-indigo-200/60"
        >
          <Languages size={56} />
        </motion.div>

        <div className="space-y-4">
          <motion.h1 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            className="text-5xl font-black text-slate-900 tracking-tight leading-tight"
          >
            WortHain
          </motion.h1>
          <motion.p 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ delay: 0.1 }}
            className="text-slate-400 font-medium tracking-wide max-w-xs mx-auto"
          >
            Precision German learning.<br />Built for the modern mind.
          </motion.p>
        </div>

        <motion.div 
          initial={{ opacity: 0, scale: 0.8 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ delay: 0.2 }}
          className="relative w-full max-w-sm"
        >
          <div className="w-full aspect-[4/3] bg-white rounded-4xl shadow-xl shadow-indigo-100/30 overflow-hidden relative border border-white">
             <div className="absolute inset-0 bg-gradient-to-tr from-indigo-500/10 to-purple-500/10 mix-blend-overlay z-10" />
             <img 
               src="https://images.unsplash.com/photo-1527866512907-4471bd5d10d1?auto=format&fit=crop&q=80&w=1000" 
               alt="Geometric Pattern" 
               className="w-full h-full object-cover opacity-80"
               referrerPolicy="no-referrer"
             />
          </div>
        </motion.div>
      </div>

      <div className="w-full max-w-xs flex flex-col gap-4 mt-12">
        <Button onClick={signIn} size="lg" className="w-full">
          Sign In
        </Button>
        <Button variant="secondary" size="lg" className="w-full text-xs tracking-ultra">
          Create Account
        </Button>
        <button className="text-slate-300 text-[10px] font-black uppercase tracking-ultra hover:text-indigo-600 transition-colors mt-2">
          Continue as Guest
        </button>
      </div>
    </div>
  );
}
