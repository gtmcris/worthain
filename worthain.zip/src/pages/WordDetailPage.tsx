import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { doc, getDoc, updateDoc } from 'firebase/firestore';
import { db } from '../lib/firebase';
import { Vocabulary } from '../types';
import { Card, Button } from '../components/UI';
import { ChevronLeft, Star, MoreHorizontal, Volume2, Edit2, PlayCircle, BarChart3 } from 'lucide-react';
import { motion, AnimatePresence } from 'motion/react';
import { cn } from '../lib/utils';

export function WordDetailPage() {
  const { id } = useParams();
  const navigate = useNavigate();
  const [word, setWord] = useState<Vocabulary | null>(null);
  const [activeTab, setActiveTab] = useState('übersicht');
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    if (id) fetchWord();
  }, [id]);

  const fetchWord = async () => {
    const docRef = doc(db, 'vocabularies', id!);
    const docSnap = await getDoc(docRef);
    if (docSnap.exists()) {
      setWord({ id: docSnap.id, ...docSnap.data() } as Vocabulary);
    }
    setLoading(false);
  };

  const toggleFavorite = async () => {
    if (!word || !id) return;
    const newStatus = word.status === 'favorite' ? 'learning' : 'favorite';
    await updateDoc(doc(db, 'vocabularies', id), { status: newStatus });
    setWord({ ...word, status: newStatus });
  };

  if (loading) return null;
  if (!word) return <div>Word not found</div>;

  const tabs = [
    { id: 'übersicht', label: 'Overview' },
    { id: 'details', label: 'Analysis' },
  ];

  return (
    <div className="min-h-screen bg-brand-bg pb-40">
      <header className="px-6 pt-16">
        <div className="flex items-center justify-between">
          <button onClick={() => navigate(-1)} className="w-12 h-12 bg-white rounded-2xl shadow-sm border border-slate-100 flex items-center justify-center text-slate-400 hover:text-indigo-600 transition-all">
            <ChevronLeft size={24} />
          </button>
          <div className="flex items-center gap-3">
            <button onClick={toggleFavorite} className={cn("w-12 h-12 rounded-2xl flex items-center justify-center transition-all", word.status === 'favorite' ? "bg-amber-50 text-amber-500" : "bg-white text-slate-300 border border-slate-100")}>
              <Star size={24} fill={word.status === 'favorite' ? "currentColor" : "none"} />
            </button>
          </div>
        </div>

        <div className="mt-12 space-y-4">
          <div className="flex items-start justify-between">
            <div className="space-y-1">
               <h1 className="text-5xl font-black text-slate-900 tracking-tight leading-none">{word.term}</h1>
               <p className="text-lg text-slate-400 font-medium tracking-wide">/phonetic/</p>
            </div>
            <div className="bg-indigo-50 text-indigo-600 px-4 py-2 rounded-xl text-[10px] font-black uppercase tracking-ultra">
              {word.grammar.type}, {word.grammar.genus}
            </div>
          </div>

          <div className="h-[1px] w-full bg-slate-100/50 my-8" />

          <div className="flex items-center gap-6">
             <div className="w-14 h-14 bg-indigo-600 rounded-3xl flex items-center justify-center text-white shrink-0 shadow-lg shadow-indigo-200/50">
               <span className="font-black text-lg">EN</span>
             </div>
             <div className="flex-1">
                <p className="text-2xl font-black text-slate-900 tracking-tight leading-tight">{word.translation}</p>
                <p className="text-slate-400 text-[10px] font-black tracking-ultra uppercase mt-1">Definition</p>
             </div>
          </div>
        </div>

        <div className="flex gap-8 mt-12 border-b border-slate-100 overflow-x-auto no-scrollbar">
          {tabs.map((tab) => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id)}
              className={cn(
                "pb-4 text-[10px] font-black uppercase tracking-ultra whitespace-nowrap transition-all relative",
                activeTab === tab.id ? "text-indigo-600" : "text-slate-300 hover:text-slate-400"
              )}
            >
              {tab.label}
              {activeTab === tab.id && (
                <motion.div layoutId="tab-underline" className="absolute bottom-0 left-0 right-0 h-1 bg-indigo-600 rounded-full" />
              )}
            </button>
          ))}
        </div>
      </header>

      <main className="px-6 mt-10">
        <AnimatePresence mode="wait">
          {activeTab === 'übersicht' && (
            <motion.div
              key="übersicht"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -10 }}
              className="space-y-10"
            >
              <div className="space-y-6">
                <h3 className="text-[10px] font-black text-slate-300 uppercase tracking-ultra px-2">Example Use Cases</h3>
                <div className="space-y-4">
                  {word.exampleSentences.slice(0, 2).map((ex, i) => (
                    <div key={i} className="bg-white border border-slate-100 p-8 rounded-[2.5rem] shadow-sm relative group">
                       <p className="text-base font-bold text-slate-800 leading-relaxed italic">
                         "{ex.de}"
                       </p>
                       <p className="text-xs text-slate-400 font-medium mt-3">{ex.en}</p>
                    </div>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                 <div className="flex justify-between items-center px-2">
                    <h3 className="text-[10px] font-black text-slate-300 uppercase tracking-ultra">Learning Notes</h3>
                    <button className="text-indigo-600"><Edit2 size={18} /></button>
                 </div>
                 <Card className="rounded-[2.5rem] bg-indigo-600 text-white border-none p-8 shadow-xl shadow-indigo-200">
                    <p className="text-sm font-medium italic leading-relaxed opacity-90">
                      {word.notes || "Add your personal memory hooks here to master this word faster."}
                    </p>
                 </Card>
              </div>
            </motion.div>
          )}

          {activeTab === 'details' && (
            <motion.div
              key="details"
              initial={{ opacity: 0, y: 10 }}
              animate={{ opacity: 1, y: 0 }}
              className="space-y-10"
            >
              <div className="space-y-6">
                 <h3 className="text-[10px] font-black text-slate-300 uppercase tracking-ultra px-2">Linguistic Data</h3>
                 <Card className="p-2 space-y-0 shadow-sm border-slate-100">
                    {[
                      { l: 'Plural', v: word.grammar.plural || 'None' },
                      { l: 'Level', v: word.level },
                      { l: 'Frequency', v: `${word.frequency}/5` }
                    ].map((row, i) => (
                      <div key={row.l} className={cn("flex justify-between items-center p-6", i < 2 && "border-b border-slate-50")}>
                         <span className="text-[10px] font-black text-slate-300 uppercase tracking-ultra">{row.l}</span>
                         <span className="text-sm font-black text-slate-800">{row.v}</span>
                      </div>
                    ))}
                 </Card>
              </div>

              <div className="space-y-6">
                <h3 className="text-[10px] font-black text-slate-300 uppercase tracking-ultra px-2">Frequency Matrix</h3>
                <div className="h-48 bg-white p-10 rounded-[3rem] border border-slate-100 shadow-sm flex items-end justify-between gap-4">
                   {[
                     { label: 'A1', val: 23 },
                     { label: 'A2', val: 68 },
                     { label: 'B1', val: 112 },
                     { label: 'B2', val: 76 },
                     { label: 'C1', val: 24 },
                     { label: 'C2', val: 9 }
                   ].map(bar => (
                     <div key={bar.label} className="flex-1 flex flex-col items-center gap-3">
                        <div 
                          className={cn("w-full rounded-full transition-all duration-1000", bar.label === word.level ? "bg-indigo-600 shadow-lg shadow-indigo-100" : "bg-slate-50")} 
                          style={{ height: `${(bar.val / 112) * 100}%` }} 
                        />
                        <span className={cn("text-[9px] font-black tracking-ultra", bar.label === word.level ? "text-indigo-600" : "text-slate-300")}>{bar.label}</span>
                     </div>
                   ))}
                </div>
              </div>
            </motion.div>
          )}
        </AnimatePresence>
      </main>

      <footer className="fixed bottom-24 left-0 right-0 px-8 z-40">
         <Button 
          className="w-full shadow-2xl py-5" 
          onClick={() => navigate('/practice')}
        >
           <PlayCircle size={22} className="mr-3" />
           Practice Word
         </Button>
      </footer>
    </div>
  );
}
