import React from 'react';
import { NavLink } from 'react-router-dom';
import { Home, Search, BookOpen, BarChart2, User } from 'lucide-react';
import { cn } from '../lib/utils';

export function Navigation() {
  const navItems = [
    { to: '/', icon: Home, label: 'Start' },
    { to: '/search', icon: Search, label: 'Finder' },
    { to: '/practice', icon: BookOpen, label: 'Cards' },
    { to: '/stats', icon: BarChart2, label: 'Stats' },
    { to: '/profile', icon: User, label: 'Profil' },
  ];

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t border-slate-200 px-6 py-4 pb-10 z-50">
      <div className="max-w-md mx-auto flex justify-between items-center">
        {navItems.map(({ to, icon: Icon, label }) => (
          <NavLink
            key={to}
            to={to}
            className={({ isActive }) =>
              cn(
                "flex flex-col items-center space-y-1.5 px-3 py-2 rounded-2xl transition-all duration-300 min-w-[64px]",
                isActive 
                  ? "bg-indigo-50 text-indigo-700 border border-indigo-100 shadow-sm shadow-indigo-100/20" 
                  : "text-slate-400 hover:text-slate-600 hover:bg-slate-50"
              )
            }
          >
            <Icon size={20} className={cn("transition-transform duration-300")} />
            <span className="text-[9px] font-black uppercase tracking-ultra">{label}</span>
          </NavLink>
        ))}
      </div>
    </nav>
  );
}
